# Frequently Asked Questions


### My product / products are not showing up. What is wrong?

 - Is the store open?
 - Have you enabled 'AllowPurcahse' for each product?
 - Do your products have a price?

Order Fulfilment System
========================

The eCommerce module provide a mechanism for customising the order fulfilment pipeline. A pipeline is made up of a series of OrderSteps.

After an order is placed, it is immediately put into the fulfilment pipeline, where is progresses automatically through the order steps until human intervention is required, or the order exits the pipeline as a fulfilled order.



Example steps
-------------
 - Send email notification to customer
 - Supplier stock check
 - Processing


How to configure...

How to customise...
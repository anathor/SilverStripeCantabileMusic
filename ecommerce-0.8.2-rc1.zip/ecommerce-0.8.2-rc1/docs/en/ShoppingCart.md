# Shopping Cart
How it works, and how to extend it.


## Order Item Parameters
You may want to add seperate types of the same item to a cart.
for example: "12 meters of rope", along with "5 meters of rope".
or another example: "chicken soup" for delivery this week, along with "chicken soup" for delivery in two weeks

The ecommerce module supports such products.

Making use of this requires:
 - adding parameters to url links / forms
 - modifying order item to store data, such as length, or group
 
 todo...how to do implement
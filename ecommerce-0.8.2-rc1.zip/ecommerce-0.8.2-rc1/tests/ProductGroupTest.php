<?php

class ProductGroupTest extends SapphireTest{
	
	//TODO: check that sub-category products show up
	//TODO: check filtering
	
	//check published/ non published / allow purchase etc
	
}

?>
